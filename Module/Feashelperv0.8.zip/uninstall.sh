MODDIR=${0%/*}
rm -rf /data/feas.conf
rm -rf /data/feas.conf.bak