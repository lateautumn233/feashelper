MODDIR=${0%/*}
#rm rubbish
rm -rf /data/feas.conf
rm -rf /data/feas.conf.bak